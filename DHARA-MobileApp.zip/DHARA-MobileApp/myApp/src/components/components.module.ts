import { NgModule } from '@angular/core';
import { HeaderMenuComponent } from './header-menu/header-menu';
@NgModule({
	declarations: [HeaderMenuComponent],
	imports: [],
	exports: [HeaderMenuComponent]
})
export class ComponentsModule {}
